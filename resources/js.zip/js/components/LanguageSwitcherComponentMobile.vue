<template>
  <!-- desktop -->
  <div class="nav__mobile-lang">
    <a
      class=""
      href="#"
      @click.prevent="changeLanguage('en')"
      v-bind:class="[defualt == 'en' ? 'active' : '']"
    >
      ENG
    </a>
    <a
      href="#"
      @click.prevent="changeLanguage('de')"
      v-bind:class="[defualt == 'de' ? 'active' : '']"
      >DE</a
    >
    <a
      href="#"
      @click.prevent="changeLanguage('hr')"
      v-bind:class="[defualt == 'hr' ? 'active' : '']"
      >HR</a
    >
  </div>
</template>

<script>
export default {
  props: ['defualt'],

  methods: {
    changeLanguage(lang) {
      axios.post('/set_session', { language: lang });
      location.reload();
    },
  },
};
</script>

<style scoped></style>
