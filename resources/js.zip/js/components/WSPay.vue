<template>
  <!-- wspay logotipi -->

  <div class="container" style="margin-bottom: 1.5em;">
    <div style="display: flex; justify-content: flex-end; ">
      <a
        href="http://www.americanexpress.hr/"
        style="border-bottom:none;"
        target="_blank"
        title="American Express"
        height="30"
      >
        <img
          title="American Express"
          src="/images/AmericanExpress50.svg"
          alt="American Express"
          border="0"
          class="wspay-icon"
          height="30"
        />
      </a>
      <a
        href="http://www.diners.com.hr"
        style="border-bottom:none;"
        target="_blank"
        title="Diners Club International"
      >
        <img
          alt="Diners Club International"
          border="0"
          src="/images/dinersClub.svg"
          class="wspay-icon"
          height="30"
        />
      </a>
      <a
        href="http://www.visa.com.hr/"
        style="border-bottom:none;"
        target="_blank"
        title="Visa"
      >
        <img
          alt="Visa"
          border="0"
          src="/images/visa.svg"
          class="wspay-icon"
          height="30"
        />
      </a>
      <a
        href="http://www.mastercard.com/hr/"
        style="border-bottom:none;"
        target="_blank"
        title="MasterCard"
      >
        <img
          alt="MasterCard"
          border="0"
          src="/images/MasterCard.jpg"
          class="wspay-icon"
          height="30"
        />
      </a>
      <a
        href="http://www.mastercard.com/hr/"
        style="border-bottom:none;"
        target="_blank"
        title="Maestro"
      >
        <img
          alt="Maestro"
          border="0"
          src="/images/maestro50.svg"
          class="wspay-icon"
          height="30"
        />
      </a>
      <a
        href="https://www.discover.com/"
        style="border-bottom:none;"
        target="_blank"
        title="Discover"
      >
        <img
          alt="Discover"
          border="0"
          src="/images/discoverNetwork.svg"
          class="wspay-icon"
          height="30"
        />
      </a>

      <!-- <a
        href="https://www.wspay.info/verified-by-visa.html"
        style="border-bottom:none;"
        target="_blank"
        title="Visa Secure"
      >
        <img
          alt="Visa Secure"
          border="0"
          src="/images/VerifiedbyVisa.svg"
          class="wspay-icon"
          height="20"
        />
      </a> -->
      <a
        href="http://www.diners.com.hr/"
        style="border-bottom:none;"
        target="_blank"
        title="Dinacard"
      >
        <img
          alt="Dinacard"
          border="0"
          src="/images/dinaCard.svg"
          class="wspay-icon"
          height="30"
        />
      </a>

      <a
        href="https://www.mastercard.us/en-us.html"
        style="border-bottom:none;"
        title="WSpay - Web Secure Payment Gateway"
        target="_blank"
      >
        <img
          alt="WSPay"
          border="0"
          src="/images/mastercard-identity-check.png"
          class="wspay-icon"
          height="30"
        />
      </a>
      <a
        href="https://www.visa.co.uk/pay-with-visa/featured-technologies/verified-by-visa.html"
        style="border-bottom:none;"
        title="WSpay - Web Secure Payment Gateway"
        target="_blank"
      >
        <img
          alt="WSPay"
          border="0"
          src="/images/visaSecure.svg"
          class="wspay-icon"
          height="30"
        />
      </a>
      <a
        href="https://www.wspay.info"
        style="border-bottom:none;"
        title="WSpay - Web Secure Payment Gateway"
        target="_blank"
      >
        <img
          alt="WSPay"
          border="0"
          src="/images/wspay.svg"
          class="wspay-icon"
          height="30"
        />
      </a>
    </div>

    <div style="display: flex; justify-content: flex-end">
      <!-- <a
        href="http://www.americanexpress.hr/"
        style="border-bottom:none;"
        target="_blank"
        title="American"
      >
        <img
          title="American Express"
          src="/images/americanProtection.svg"
          alt="American Protection"
          border="0"
          class="wspay-icon"
          height="30"
        />
      </a> -->

      <!-- <a
        href="https://www.wspay.info/mastercard-securecode.html"
        style="border-bottom:none;"
        target="_blank"
        title="Mastercard® Identity Check™"
      >
        <img
          alt="Mastercard® Identity Check™"
          border="0"
          src="/images/secureCode_logo.svg"
          class="wspay-icon"
          height="30"
        />
      </a> -->
    </div>
    <div style="display: flex; justify-content: space-around"></div>
  </div>
  <!-- wspay end -->
</template>

<script>
export default {
  mounted() {
    console.log('Component mounted.');
  },
};
</script>

<style scoped>
a {
  padding: 5px;
}
</style>
